---
name: Bug report
about: Report some code color or UI display error.
---
<!-- It is strongly recommended to upgrade Eva Theme to the latest version first and then see if the problem persists. -->

### Screenshot
<!-- Cut the error screenshot here. -->

### Code Snippet
<!-- Copy the error code snippet below, please indicate what programming language it is. -->

```

```

## Notes
<!-- more description ? -->