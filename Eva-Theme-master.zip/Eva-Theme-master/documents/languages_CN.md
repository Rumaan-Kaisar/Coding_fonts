已在下列语言原生环境中(不包含衍生框架)做测试:

- HTML / XML / JSX / WXML
- CSS / LESS / SCSS / WXSS
- JavaScript / TypeScript
- C / C++ / C#
- Java
- PHP
- Rust
- Ruby
- Python
- Golang
- Haskell
- Dart
- JSON
- Latex
- Markdown
- Julia
- Lua

其它语言也有语法高亮，但暂时不能保证全部语义化。