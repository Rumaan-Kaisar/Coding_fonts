Tested with the following languages in native environment, except derived frameworks:

- HTML / XML / JSX / WXML
- CSS / LESS / SCSS / WXSS
- JavaScript / TypeScript
- C / C++ / C#
- Java
- PHP
- Rust
- Ruby
- Python
- Golang
- Haskell
- Dart
- JSON
- Latex
- Markdown
- Julia
- Lua

Other languages have syntax highlighting too, it's just not guaranteed to be semantic yet.
