
```json
//settings.json
{
	//put those into your settings.json, then change the colors as you like.
    "workbench.colorCustomizations": {
        "activityBar.activeBackground": "#282c34",
		"activityBar.activeBorder": "#282c34",
		"activityBar.background": "#282c34",
		"breadcrumb.background": "#282c34",
		"editor.background": "#282c34",
		"editorGutter.background": "#282c34",
		"editorOverviewRuler.background": "#282c34",
		"input.background": "#282c34",
		"minimap.background": "#282c34",
		"panel.background": "#282c34",
		"peekViewResult.background": "#282c34",
		"peekViewTitle.background": "#282c34",
		"sideBarSectionHeader.background": "#282c34",
		"tab.activeBackground": "#282c34",
		"tab.unfocusedActiveBackground": "#282c34",
		"terminal.background": "#282c34",
		"titleBar.activeBackground": "#282c34",
		"titleBar.inactiveBackground": "#282c34",
		"welcomePage.background": "#282c34",
		"welcomePage.progress.background": "#282c34",

        "menu.background": "#21252b",
        "editorPane.background": "#21252B",
		"tab.inactiveBackground": "#21252B",
        "sideBar.background": "#21252B",
        "statusBar.background": "#21252B",
		"editorGroupHeader.tabsBackground": "#21252B",
		"editorGroupHeader.noTabsBackground": "#21252B",

		"editor.lineHighlightBackground": "#2F323B",
    },
}
```